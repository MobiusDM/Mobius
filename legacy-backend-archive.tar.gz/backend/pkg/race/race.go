// Package race can be used to detect if -race is enabled.
package race

// Enabled is true if -race is enabled, false otherwise.
var Enabled = enabled
