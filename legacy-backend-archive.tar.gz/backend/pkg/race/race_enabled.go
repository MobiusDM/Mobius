//go:build race
// +build race

package race

var enabled = true
