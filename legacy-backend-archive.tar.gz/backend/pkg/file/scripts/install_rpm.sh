#!/bin/sh

dnf install --assumeyes "$INSTALLER_PATH"
