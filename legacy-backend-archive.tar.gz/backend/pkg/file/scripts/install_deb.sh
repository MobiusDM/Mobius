#!/bin/sh

apt-get install --assume-yes -f "$INSTALLER_PATH"
