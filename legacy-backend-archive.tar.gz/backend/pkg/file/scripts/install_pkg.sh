#!/bin/sh

installer -pkg "$INSTALLER_PATH" -target /
