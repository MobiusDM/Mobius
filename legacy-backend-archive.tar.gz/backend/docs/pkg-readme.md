# pkg directory

This top-level `pkg` directory contains packages that may be shared between all `mobius` backend components.
