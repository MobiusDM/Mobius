package mobius

const ApiVersion = "v1"
