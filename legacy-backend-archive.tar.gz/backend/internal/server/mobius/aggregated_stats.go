package mobius

const (
	AggregatedStatsTypeScheduledQuery = "scheduled_query"
)

type AggregatedStatsType string
