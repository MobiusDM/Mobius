package service

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"regexp"
	"strings"
	"time"

	// service "github.com/notawar/mobius/internal/server/service" // Removed enterprise dependency
	kithttp "github.com/go-kit/kit/transport/http"
	kitlog "github.com/go-kit/log"
	"github.com/go-kit/log/level"
	"github.com/gorilla/mux"
	nanomdm_log "github.com/micromdm/nanolib/log"
	"github.com/notawar/mobius/internal/server/config"
	"github.com/notawar/mobius/internal/server/contexts/publicip"
	apple_mdm "github.com/notawar/mobius/internal/server/mdm/apple"
	mdmcrypto "github.com/notawar/mobius/internal/server/mdm/crypto"
	"github.com/notawar/mobius/internal/server/mdm/nanomdm/cryptoutil"
	httpmdm "github.com/notawar/mobius/internal/server/mdm/nanomdm/http/mdm"
	nanomdm_service "github.com/notawar/mobius/internal/server/mdm/nanomdm/service"
	"github.com/notawar/mobius/internal/server/mdm/nanomdm/service/certauth"
	"github.com/notawar/mobius/internal/server/mdm/nanomdm/service/multi"
	"github.com/notawar/mobius/internal/server/mdm/nanomdm/service/nanomdm"
	scep_depot "github.com/notawar/mobius/internal/server/mdm/scep/depot"
	scepserver "github.com/notawar/mobius/internal/server/mdm/scep/server"
	"github.com/notawar/mobius/internal/server/mobius"
	"github.com/notawar/mobius/internal/server/service/contract"
	"github.com/notawar/mobius/internal/server/service/middleware/auth"
	"github.com/notawar/mobius/internal/server/service/middleware/endpoint_utils"
	"github.com/notawar/mobius/internal/server/service/middleware/log"
	"github.com/notawar/mobius/internal/server/service/middleware/mdmconfigured"
	"github.com/notawar/mobius/internal/server/service/middleware/ratelimit"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/throttled/throttled/v2"
	"go.elastic.co/apm/module/apmgorilla/v2"
	otmiddleware "go.opentelemetry.io/contrib/instrumentation/github.com/gorilla/mux/otelmux"

	microsoft_mdm "github.com/notawar/mobius/internal/server/mdm/microsoft"
)

func checkLicenseExpiration(svc mobius.Service) func(context.Context, http.ResponseWriter) context.Context {
	return func(ctx context.Context, w http.ResponseWriter) context.Context {
		license, err := svc.License(ctx)
		if err != nil || license == nil {
			return ctx
		}
		if license.IsPremium() && license.IsExpired() {
			w.Header().Set(mobius.HeaderLicenseKey, mobius.HeaderLicenseValueExpired)
		}
		return ctx
	}
}

type extraHandlerOpts struct {
	loginRateLimit  *throttled.Rate
	mdmSsoRateLimit *throttled.Rate
}

// ExtraHandlerOption allows adding extra configuration to the HTTP handler.
type ExtraHandlerOption func(*extraHandlerOpts)

// WithLoginRateLimit configures the rate limit for the login endpoints.
func WithLoginRateLimit(r throttled.Rate) ExtraHandlerOption {
	return func(o *extraHandlerOpts) {
		o.loginRateLimit = &r
	}
}

// WithMdmSsoRateLimit configures the rate limit for the MDM SSO endpoints (falls back to login rate limit otherwise).
func WithMdmSsoRateLimit(r throttled.Rate) ExtraHandlerOption {
	return func(o *extraHandlerOpts) {
		o.mdmSsoRateLimit = &r
	}
}

// MakeHandler creates an HTTP handler for the Mobius server endpoints.
func MakeHandler(
	svc mobius.Service,
	config config.MobiusConfig,
	logger kitlog.Logger,
	limitStore throttled.GCRAStore,
	featureRoutes []endpoint_utils.HandlerRoutesFunc,
	extra ...ExtraHandlerOption,
) http.Handler {
	var eopts extraHandlerOpts
	for _, fn := range extra {
		fn(&eopts)
	}

	mobiusAPIOptions := []kithttp.ServerOption{
		kithttp.ServerBefore(
			kithttp.PopulateRequestContext, // populate the request context with common fields
			auth.SetRequestsContexts(svc),
		),
		kithttp.ServerErrorHandler(&endpoint_utils.ErrorHandler{Logger: logger}),
		kithttp.ServerErrorEncoder(endpoint_utils.EncodeError),
		kithttp.ServerAfter(
			kithttp.SetContentType("application/json; charset=utf-8"),
			log.LogRequestEnd(logger),
			checkLicenseExpiration(svc),
		),
	}

	r := mux.NewRouter()
	if config.Logging.TracingEnabled {
		if config.Logging.TracingType == "opentelemetry" {
			r.Use(otmiddleware.Middleware("mobius"))
		} else {
			apmgorilla.Instrument(r)
		}
	}

	r.Use(publicIP)

	attachMobiusAPIRoutes(r, svc, config, logger, limitStore, mobiusAPIOptions, eopts)
	for _, featureRoute := range featureRoutes {
		featureRoute(r, mobiusAPIOptions)
	}
	addMetrics(r)

	return r
}

func publicIP(handler http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip := endpoint_utils.ExtractIP(r)
		if ip != "" {
			r.RemoteAddr = ip
		}
		handler.ServeHTTP(w, r.WithContext(publicip.NewContext(r.Context(), ip)))
	})
}

// PrometheusMetricsHandler wraps the provided handler with prometheus metrics
// middleware and returns the resulting handler that should be mounted for that
// route.
func PrometheusMetricsHandler(name string, handler http.Handler) http.Handler {
	reg := prometheus.DefaultRegisterer
	registerOrExisting := func(coll prometheus.Collector) prometheus.Collector {
		if err := reg.Register(coll); err != nil {
			if are, ok := err.(prometheus.AlreadyRegisteredError); ok {
				return are.ExistingCollector
			}
			panic(err)
		}
		return coll
	}

	// this configuration is to keep prometheus metrics as close as possible to
	// what the v0.9.3 (that we used to use) provided via the now-deprecated
	// prometheus.InstrumentHandler.

	reqCnt := registerOrExisting(prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Subsystem:   "http",
			Name:        "requests_total",
			Help:        "Total number of HTTP requests made.",
			ConstLabels: prometheus.Labels{"handler": name},
		},
		[]string{"method", "code"},
	)).(*prometheus.CounterVec)

	reqDur := registerOrExisting(prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Subsystem:   "http",
			Name:        "request_duration_seconds",
			Help:        "The HTTP request latencies in seconds.",
			ConstLabels: prometheus.Labels{"handler": name},
			// Use default buckets, as they are suited for durations.
		},
		nil,
	)).(*prometheus.HistogramVec)

	// 1KB, 100KB, 1MB, 100MB, 1GB
	sizeBuckets := []float64{1024, 100 * 1024, 1024 * 1024, 100 * 1024 * 1024, 1024 * 1024 * 1024}

	resSz := registerOrExisting(prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Subsystem:   "http",
			Name:        "response_size_bytes",
			Help:        "The HTTP response sizes in bytes.",
			ConstLabels: prometheus.Labels{"handler": name},
			Buckets:     sizeBuckets,
		},
		nil,
	)).(*prometheus.HistogramVec)

	reqSz := registerOrExisting(prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Subsystem:   "http",
			Name:        "request_size_bytes",
			Help:        "The HTTP request sizes in bytes.",
			ConstLabels: prometheus.Labels{"handler": name},
			Buckets:     sizeBuckets,
		},
		nil,
	)).(*prometheus.HistogramVec)

	return promhttp.InstrumentHandlerDuration(reqDur,
		promhttp.InstrumentHandlerCounter(reqCnt,
			promhttp.InstrumentHandlerResponseSize(resSz,
				promhttp.InstrumentHandlerRequestSize(reqSz, handler))))
}

// addMetrics decorates each handler with prometheus instrumentation
func addMetrics(r *mux.Router) {
	walkFn := func(route *mux.Route, router *mux.Router, ancestors []*mux.Route) error {
		route.Handler(PrometheusMetricsHandler(route.GetName(), route.GetHandler()))
		return nil
	}
	r.Walk(walkFn) //nolint:errcheck
}

// These are defined as const so that they can be used in tests.
const (
	desktopRateLimitMaxBurst        = 100 // Max burst used for device request rate limiting.
	forgotPasswordRateLimitMaxBurst = 9   // Max burst used for rate limiting on the the forgot_password endpoint.
)

func attachMobiusAPIRoutes(r *mux.Router, svc mobius.Service, config config.MobiusConfig,
	logger kitlog.Logger, limitStore throttled.GCRAStore, opts []kithttp.ServerOption,
	extra extraHandlerOpts,
) {
	apiVersions := []string{"v1", "2022-04"}

	// user-authenticated endpoints
	ue := newUserAuthenticatedEndpointer(svc, opts, r, apiVersions...)

	ue.POST("/api/_version_/mobius/trigger", triggerEndpoint, triggerRequest{})

	ue.GET("/api/_version_/mobius/me", meEndpoint, getMeRequest{})
	ue.GET("/api/_version_/mobius/sessions/{id:[0-9]+}", getInfoAboutSessionEndpoint, getInfoAboutSessionRequest{})
	ue.DELETE("/api/_version_/mobius/sessions/{id:[0-9]+}", deleteSessionEndpoint, deleteSessionRequest{})

	ue.GET("/api/_version_/mobius/config/certificate", getCertificateEndpoint, nil)
	ue.GET("/api/_version_/mobius/config", getAppConfigEndpoint, nil)
	ue.PATCH("/api/_version_/mobius/config", modifyAppConfigEndpoint, modifyAppConfigRequest{})
	ue.POST("/api/_version_/mobius/spec/enroll_secret", applyEnrollSecretSpecEndpoint, applyEnrollSecretSpecRequest{})
	ue.GET("/api/_version_/mobius/spec/enroll_secret", getEnrollSecretSpecEndpoint, nil)
	ue.GET("/api/_version_/mobius/version", versionEndpoint, nil)

	ue.POST("/api/_version_/mobius/users/roles/spec", applyUserRoleSpecsEndpoint, applyUserRoleSpecsRequest{})
	ue.POST("/api/_version_/mobius/translate", translatorEndpoint, translatorRequest{})
	ue.POST("/api/_version_/mobius/spec/teams", applyTeamSpecsEndpoint, applyTeamSpecsRequest{})
	ue.PATCH("/api/_version_/mobius/teams/{team_id:[0-9]+}/secrets", modifyTeamEnrollSecretsEndpoint, modifyTeamEnrollSecretsRequest{})
	ue.POST("/api/_version_/mobius/teams", createTeamEndpoint, createTeamRequest{})
	ue.GET("/api/_version_/mobius/teams", listTeamsEndpoint, listTeamsRequest{})
	ue.GET("/api/_version_/mobius/teams/{id:[0-9]+}", getTeamEndpoint, getTeamRequest{})
	ue.PATCH("/api/_version_/mobius/teams/{id:[0-9]+}", modifyTeamEndpoint, modifyTeamRequest{})
	ue.DELETE("/api/_version_/mobius/teams/{id:[0-9]+}", deleteTeamEndpoint, deleteTeamRequest{})
	ue.POST("/api/_version_/mobius/teams/{id:[0-9]+}/agent_options", modifyTeamAgentOptionsEndpoint, modifyTeamAgentOptionsRequest{})
	ue.GET("/api/_version_/mobius/teams/{id:[0-9]+}/users", listTeamUsersEndpoint, listTeamUsersRequest{})
	ue.PATCH("/api/_version_/mobius/teams/{id:[0-9]+}/users", addTeamUsersEndpoint, modifyTeamUsersRequest{})
	ue.DELETE("/api/_version_/mobius/teams/{id:[0-9]+}/users", deleteTeamUsersEndpoint, modifyTeamUsersRequest{})
	ue.GET("/api/_version_/mobius/teams/{id:[0-9]+}/secrets", teamEnrollSecretsEndpoint, teamEnrollSecretsRequest{})

	ue.GET("/api/_version_/mobius/users", listUsersEndpoint, listUsersRequest{})
	ue.POST("/api/_version_/mobius/users/admin", createUserEndpoint, createUserRequest{})
	ue.GET("/api/_version_/mobius/users/{id:[0-9]+}", getUserEndpoint, getUserRequest{})
	ue.PATCH("/api/_version_/mobius/users/{id:[0-9]+}", modifyUserEndpoint, modifyUserRequest{})
	ue.DELETE("/api/_version_/mobius/users/{id:[0-9]+}", deleteUserEndpoint, deleteUserRequest{})
	ue.POST("/api/_version_/mobius/users/{id:[0-9]+}/require_password_reset", requirePasswordResetEndpoint, requirePasswordResetRequest{})
	ue.GET("/api/_version_/mobius/users/{id:[0-9]+}/sessions", getInfoAboutSessionsForUserEndpoint, getInfoAboutSessionsForUserRequest{})
	ue.DELETE("/api/_version_/mobius/users/{id:[0-9]+}/sessions", deleteSessionsForUserEndpoint, deleteSessionsForUserRequest{})
	ue.POST("/api/_version_/mobius/change_password", changePasswordEndpoint, changePasswordRequest{})

	ue.GET("/api/_version_/mobius/email/change/{token}", changeEmailEndpoint, changeEmailRequest{})
	// TODO: searchTargetsEndpoint will be removed in Mobius 5.0
	ue.POST("/api/_version_/mobius/targets", searchTargetsEndpoint, searchTargetsRequest{})
	ue.POST("/api/_version_/mobius/targets/count", countTargetsEndpoint, countTargetsRequest{})

	ue.POST("/api/_version_/mobius/invites", createInviteEndpoint, createInviteRequest{})
	ue.GET("/api/_version_/mobius/invites", listInvitesEndpoint, listInvitesRequest{})
	ue.DELETE("/api/_version_/mobius/invites/{id:[0-9]+}", deleteInviteEndpoint, deleteInviteRequest{})
	ue.PATCH("/api/_version_/mobius/invites/{id:[0-9]+}", updateInviteEndpoint, updateInviteRequest{})

	ue.EndingAtVersion("v1").POST("/api/_version_/mobius/global/policies", globalPolicyEndpoint, globalPolicyRequest{})
	ue.StartingAtVersion("2022-04").POST("/api/_version_/mobius/policies", globalPolicyEndpoint, globalPolicyRequest{})
	ue.EndingAtVersion("v1").GET("/api/_version_/mobius/global/policies", listGlobalPoliciesEndpoint, listGlobalPoliciesRequest{})
	ue.StartingAtVersion("2022-04").GET("/api/_version_/mobius/policies", listGlobalPoliciesEndpoint, listGlobalPoliciesRequest{})
	ue.GET("/api/_version_/mobius/policies/count", countGlobalPoliciesEndpoint, countGlobalPoliciesRequest{})
	ue.EndingAtVersion("v1").GET("/api/_version_/mobius/global/policies/{policy_id}", getPolicyByIDEndpoint, getPolicyByIDRequest{})
	ue.StartingAtVersion("2022-04").GET("/api/_version_/mobius/policies/{policy_id}", getPolicyByIDEndpoint, getPolicyByIDRequest{})
	ue.EndingAtVersion("v1").POST("/api/_version_/mobius/global/policies/delete", deleteGlobalPoliciesEndpoint, deleteGlobalPoliciesRequest{})
	ue.StartingAtVersion("2022-04").POST("/api/_version_/mobius/policies/delete", deleteGlobalPoliciesEndpoint, deleteGlobalPoliciesRequest{})
	ue.EndingAtVersion("v1").PATCH("/api/_version_/mobius/global/policies/{policy_id}", modifyGlobalPolicyEndpoint, modifyGlobalPolicyRequest{})
	ue.StartingAtVersion("2022-04").PATCH("/api/_version_/mobius/policies/{policy_id}", modifyGlobalPolicyEndpoint, modifyGlobalPolicyRequest{})
	ue.POST("/api/_version_/mobius/automations/reset", resetAutomationEndpoint, resetAutomationRequest{})

	// Alias /api/_version_/mobius/team/ -> /api/_version_/mobius/teams/
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/policies").
		POST("/api/_version_/mobius/teams/{team_id}/policies", teamPolicyEndpoint, teamPolicyRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/policies").
		GET("/api/_version_/mobius/teams/{team_id}/policies", listTeamPoliciesEndpoint, listTeamPoliciesRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/policies/count").
		GET("/api/_version_/mobius/teams/{team_id}/policies/count", countTeamPoliciesEndpoint, countTeamPoliciesRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/policies/{policy_id}").
		GET("/api/_version_/mobius/teams/{team_id}/policies/{policy_id}", getTeamPolicyByIDEndpoint, getTeamPolicyByIDRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/policies/delete").
		POST("/api/_version_/mobius/teams/{team_id}/policies/delete", deleteTeamPoliciesEndpoint, deleteTeamPoliciesRequest{})
	ue.PATCH("/api/_version_/mobius/teams/{team_id}/policies/{policy_id}", modifyTeamPolicyEndpoint, modifyTeamPolicyRequest{})
	ue.POST("/api/_version_/mobius/spec/policies", applyPolicySpecsEndpoint, applyPolicySpecsRequest{})

	ue.GET("/api/_version_/mobius/queries/{id:[0-9]+}", getQueryEndpoint, getQueryRequest{})
	ue.GET("/api/_version_/mobius/queries", listQueriesEndpoint, listQueriesRequest{})
	ue.GET("/api/_version_/mobius/queries/{id:[0-9]+}/report", getQueryReportEndpoint, getQueryReportRequest{})
	ue.POST("/api/_version_/mobius/queries", createQueryEndpoint, createQueryRequest{})
	ue.PATCH("/api/_version_/mobius/queries/{id:[0-9]+}", modifyQueryEndpoint, modifyQueryRequest{})
	ue.DELETE("/api/_version_/mobius/queries/{name}", deleteQueryEndpoint, deleteQueryRequest{})
	ue.DELETE("/api/_version_/mobius/queries/id/{id:[0-9]+}", deleteQueryByIDEndpoint, deleteQueryByIDRequest{})
	ue.POST("/api/_version_/mobius/queries/delete", deleteQueriesEndpoint, deleteQueriesRequest{})
	ue.POST("/api/_version_/mobius/spec/queries", applyQuerySpecsEndpoint, applyQuerySpecsRequest{})
	ue.GET("/api/_version_/mobius/spec/queries", getQuerySpecsEndpoint, getQuerySpecsRequest{})
	ue.GET("/api/_version_/mobius/spec/queries/{name}", getQuerySpecEndpoint, getQuerySpecRequest{})

	ue.GET("/api/_version_/mobius/packs/{id:[0-9]+}", getPackEndpoint, getPackRequest{})
	ue.POST("/api/_version_/mobius/packs", createPackEndpoint, createPackRequest{})
	ue.PATCH("/api/_version_/mobius/packs/{id:[0-9]+}", modifyPackEndpoint, modifyPackRequest{})
	ue.GET("/api/_version_/mobius/packs", listPacksEndpoint, listPacksRequest{})
	ue.DELETE("/api/_version_/mobius/packs/{name}", deletePackEndpoint, deletePackRequest{})
	ue.DELETE("/api/_version_/mobius/packs/id/{id:[0-9]+}", deletePackByIDEndpoint, deletePackByIDRequest{})
	ue.POST("/api/_version_/mobius/spec/packs", applyPackSpecsEndpoint, applyPackSpecsRequest{})
	ue.GET("/api/_version_/mobius/spec/packs", getPackSpecsEndpoint, nil)
	ue.GET("/api/_version_/mobius/spec/packs/{name}", getPackSpecEndpoint, getGenericSpecRequest{})

	ue.GET("/api/_version_/mobius/software/versions", listSoftwareVersionsEndpoint, listSoftwareRequest{})
	ue.GET("/api/_version_/mobius/software/versions/{id:[0-9]+}", getSoftwareEndpoint, getSoftwareRequest{})

	// DEPRECATED: use /api/_version_/mobius/software/versions instead
	ue.GET("/api/_version_/mobius/software", listSoftwareEndpoint, listSoftwareRequest{})
	// DEPRECATED: use /api/_version_/mobius/software/versions{id:[0-9]+} instead
	ue.GET("/api/_version_/mobius/software/{id:[0-9]+}", getSoftwareEndpoint, getSoftwareRequest{})
	// DEPRECATED: software version counts are now included directly in the software version list
	ue.GET("/api/_version_/mobius/software/count", countSoftwareEndpoint, countSoftwareRequest{})

	ue.GET("/api/_version_/mobius/software/titles", listSoftwareTitlesEndpoint, listSoftwareTitlesRequest{})
	ue.GET("/api/_version_/mobius/software/titles/{id:[0-9]+}", getSoftwareTitleEndpoint, getSoftwareTitleRequest{})
	ue.POST("/api/_version_/mobius/hosts/{host_id:[0-9]+}/software/{software_title_id:[0-9]+}/install", installSoftwareTitleEndpoint,
		installSoftwareRequest{})
	ue.POST("/api/_version_/mobius/hosts/{host_id:[0-9]+}/software/{software_title_id:[0-9]+}/uninstall", uninstallSoftwareTitleEndpoint,
		uninstallSoftwareRequest{})

	// Software installers
	ue.GET("/api/_version_/mobius/software/titles/{title_id:[0-9]+}/package", getSoftwareInstallerEndpoint, getSoftwareInstallerRequest{})
	ue.POST("/api/_version_/mobius/software/titles/{title_id:[0-9]+}/package/token", getSoftwareInstallerTokenEndpoint,
		getSoftwareInstallerRequest{})
	ue.POST("/api/_version_/mobius/software/package", uploadSoftwareInstallerEndpoint, uploadSoftwareInstallerRequest{})
	ue.PATCH("/api/_version_/mobius/software/titles/{id:[0-9]+}/name", updateSoftwareNameEndpoint, updateSoftwareNameRequest{})
	ue.PATCH("/api/_version_/mobius/software/titles/{id:[0-9]+}/package", updateSoftwareInstallerEndpoint, updateSoftwareInstallerRequest{})
	ue.DELETE("/api/_version_/mobius/software/titles/{title_id:[0-9]+}/available_for_install", deleteSoftwareInstallerEndpoint, deleteSoftwareInstallerRequest{})
	ue.GET("/api/_version_/mobius/software/install/{install_uuid}/results", getSoftwareInstallResultsEndpoint,
		getSoftwareInstallResultsRequest{})
	// POST /api/_version_/mobius/software/batch is asynchronous, meaning it will start the process of software download+upload in the background
	// and will return a request UUID to be used in GET /api/_version_/mobius/software/batch/{request_uuid} to query for the status of the operation.
	ue.POST("/api/_version_/mobius/software/batch", batchSetSoftwareInstallersEndpoint, batchSetSoftwareInstallersRequest{})
	ue.GET("/api/_version_/mobius/software/batch/{request_uuid}", batchSetSoftwareInstallersResultEndpoint, batchSetSoftwareInstallersResultRequest{})

	// App store software
	ue.GET("/api/_version_/mobius/software/app_store_apps", getAppStoreAppsEndpoint, getAppStoreAppsRequest{})
	ue.POST("/api/_version_/mobius/software/app_store_apps", addAppStoreAppEndpoint, addAppStoreAppRequest{})
	ue.PATCH("/api/_version_/mobius/software/titles/{title_id:[0-9]+}/app_store_app", updateAppStoreAppEndpoint, updateAppStoreAppRequest{})

	// Setup Experience
	ue.PUT("/api/_version_/mobius/setup_experience/software", putSetupExperienceSoftware, putSetupExperienceSoftwareRequest{})
	ue.GET("/api/_version_/mobius/setup_experience/software", getSetupExperienceSoftware, getSetupExperienceSoftwareRequest{})
	ue.GET("/api/_version_/mobius/setup_experience/script", getSetupExperienceScriptEndpoint, getSetupExperienceScriptRequest{})
	ue.POST("/api/_version_/mobius/setup_experience/script", setSetupExperienceScriptEndpoint, setSetupExperienceScriptRequest{})
	ue.DELETE("/api/_version_/mobius/setup_experience/script", deleteSetupExperienceScriptEndpoint, deleteSetupExperienceScriptRequest{})

	// Mobius-maintained apps
	ue.POST("/api/_version_/mobius/software/mobius_maintained_apps", addMobiusMaintainedAppEndpoint, addMobiusMaintainedAppRequest{})
	ue.GET("/api/_version_/mobius/software/mobius_maintained_apps", listMobiusMaintainedAppsEndpoint, listMobiusMaintainedAppsRequest{})
	ue.GET("/api/_version_/mobius/software/mobius_maintained_apps/{app_id}", getMobiusMaintainedApp, getMobiusMaintainedAppRequest{})

	// Vulnerabilities
	ue.GET("/api/_version_/mobius/vulnerabilities", listVulnerabilitiesEndpoint, listVulnerabilitiesRequest{})
	ue.GET("/api/_version_/mobius/vulnerabilities/{cve}", getVulnerabilityEndpoint, getVulnerabilityRequest{})

	// Hosts
	ue.GET("/api/_version_/mobius/host_summary", getHostSummaryEndpoint, getHostSummaryRequest{})
	ue.GET("/api/_version_/mobius/hosts", listHostsEndpoint, listHostsRequest{})
	ue.POST("/api/_version_/mobius/hosts/delete", deleteHostsEndpoint, deleteHostsRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}", getHostEndpoint, getHostRequest{})
	ue.GET("/api/_version_/mobius/hosts/count", countHostsEndpoint, countHostsRequest{})
	ue.POST("/api/_version_/mobius/hosts/search", searchHostsEndpoint, searchHostsRequest{})
	ue.GET("/api/_version_/mobius/hosts/identifier/{identifier}", hostByIdentifierEndpoint, hostByIdentifierRequest{})
	ue.POST("/api/_version_/mobius/hosts/identifier/{identifier}/query", runLiveQueryOnHostEndpoint, runLiveQueryOnHostRequest{})
	ue.POST("/api/_version_/mobius/hosts/{id:[0-9]+}/query", runLiveQueryOnHostByIDEndpoint, runLiveQueryOnHostByIDRequest{})
	ue.DELETE("/api/_version_/mobius/hosts/{id:[0-9]+}", deleteHostEndpoint, deleteHostRequest{})
	ue.POST("/api/_version_/mobius/hosts/transfer", addHostsToTeamEndpoint, addHostsToTeamRequest{})
	ue.POST("/api/_version_/mobius/hosts/transfer/filter", addHostsToTeamByFilterEndpoint, addHostsToTeamByFilterRequest{})
	ue.POST("/api/_version_/mobius/hosts/{id:[0-9]+}/refetch", refetchHostEndpoint, refetchHostRequest{})
	// Deprecated: Emails are now included in host details endpoint: /api/_version_/mobius/hosts/{id}
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/device_mapping", listHostDeviceMappingEndpoint, listHostDeviceMappingRequest{})
	// Deprecated: Because the corresponding GET endpoint is deprecated.
	// API-first architecture provides direct API access instead.
	// Note: This endpoint provides user-authenticated access vs the removed agent-authenticated endpoint.
	ue.PUT("/api/_version_/mobius/hosts/{id:[0-9]+}/device_mapping", putHostDeviceMappingEndpoint, putHostDeviceMappingRequest{})
	ue.GET("/api/_version_/mobius/hosts/report", hostsReportEndpoint, hostsReportRequest{})
	ue.GET("/api/_version_/mobius/os_versions", osVersionsEndpoint, osVersionsRequest{})
	ue.GET("/api/_version_/mobius/os_versions/{id:[0-9]+}", getOSVersionEndpoint, getOSVersionRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/queries/{query_id:[0-9]+}", getHostQueryReportEndpoint, getHostQueryReportRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/health", getHostHealthEndpoint, getHostHealthRequest{})
	ue.POST("/api/_version_/mobius/hosts/{id:[0-9]+}/labels", addLabelsToHostEndpoint, addLabelsToHostRequest{})
	ue.DELETE("/api/_version_/mobius/hosts/{id:[0-9]+}/labels", removeLabelsFromHostEndpoint, removeLabelsFromHostRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/software", getHostSoftwareEndpoint, getHostSoftwareRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/certificates", listHostCertificatesEndpoint, listHostCertificatesRequest{})

	ue.GET("/api/_version_/mobius/hosts/summary/mdm", getHostMDMSummary, getHostMDMSummaryRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/mdm", getHostMDM, getHostMDMRequest{})

	ue.POST("/api/_version_/mobius/labels", createLabelEndpoint, createLabelRequest{})
	ue.PATCH("/api/_version_/mobius/labels/{id:[0-9]+}", modifyLabelEndpoint, modifyLabelRequest{})
	ue.GET("/api/_version_/mobius/labels/{id:[0-9]+}", getLabelEndpoint, getLabelRequest{})
	ue.GET("/api/_version_/mobius/labels", listLabelsEndpoint, listLabelsRequest{})
	ue.GET("/api/_version_/mobius/labels/summary", getLabelsSummaryEndpoint, nil)
	ue.GET("/api/_version_/mobius/labels/{id:[0-9]+}/hosts", listHostsInLabelEndpoint, listHostsInLabelRequest{})
	ue.DELETE("/api/_version_/mobius/labels/{name}", deleteLabelEndpoint, deleteLabelRequest{})
	ue.DELETE("/api/_version_/mobius/labels/id/{id:[0-9]+}", deleteLabelByIDEndpoint, deleteLabelByIDRequest{})
	ue.POST("/api/_version_/mobius/spec/labels", applyLabelSpecsEndpoint, applyLabelSpecsRequest{})
	ue.GET("/api/_version_/mobius/spec/labels", getLabelSpecsEndpoint, nil)
	ue.GET("/api/_version_/mobius/spec/labels/{name}", getLabelSpecEndpoint, getGenericSpecRequest{})

	// This endpoint runs live queries synchronously (with a configured timeout).
	ue.POST("/api/_version_/mobius/queries/{id:[0-9]+}/run", runOneLiveQueryEndpoint, runOneLiveQueryRequest{})
	// Old endpoint, removed from docs. This GET endpoint runs live queries synchronously (with a configured timeout).
	ue.GET("/api/_version_/mobius/queries/run", runLiveQueryEndpoint, runLiveQueryRequest{})
	// The following two POST APIs are the asynchronous way to run live queries.
	// The live queries are created with these two endpoints and their results can be queried via
	// websockets via the `GET /api/_version_/mobius/results/` endpoint.
	ue.POST("/api/_version_/mobius/queries/run", createDistributedQueryCampaignEndpoint, createDistributedQueryCampaignRequest{})
	ue.POST("/api/_version_/mobius/queries/run_by_identifiers", createDistributedQueryCampaignByIdentifierEndpoint, createDistributedQueryCampaignByIdentifierRequest{})
	// This endpoint is deprecated and maintained for backwards compatibility. This and above endpoint are functionally equivalent
	ue.POST("/api/_version_/mobius/queries/run_by_names", createDistributedQueryCampaignByIdentifierEndpoint, createDistributedQueryCampaignByIdentifierRequest{})

	ue.GET("/api/_version_/mobius/activities", listActivitiesEndpoint, listActivitiesRequest{})

	ue.GET("/api/_version_/mobius/packs/{id:[0-9]+}/scheduled", getScheduledQueriesInPackEndpoint, getScheduledQueriesInPackRequest{})
	ue.EndingAtVersion("v1").POST("/api/_version_/mobius/schedule", scheduleQueryEndpoint, scheduleQueryRequest{})
	ue.StartingAtVersion("2022-04").POST("/api/_version_/mobius/packs/schedule", scheduleQueryEndpoint, scheduleQueryRequest{})
	ue.GET("/api/_version_/mobius/schedule/{id:[0-9]+}", getScheduledQueryEndpoint, getScheduledQueryRequest{})
	ue.EndingAtVersion("v1").PATCH("/api/_version_/mobius/schedule/{id:[0-9]+}", modifyScheduledQueryEndpoint, modifyScheduledQueryRequest{})
	ue.StartingAtVersion("2022-04").PATCH("/api/_version_/mobius/packs/schedule/{id:[0-9]+}", modifyScheduledQueryEndpoint, modifyScheduledQueryRequest{})
	ue.EndingAtVersion("v1").DELETE("/api/_version_/mobius/schedule/{id:[0-9]+}", deleteScheduledQueryEndpoint, deleteScheduledQueryRequest{})
	ue.StartingAtVersion("2022-04").DELETE("/api/_version_/mobius/packs/schedule/{id:[0-9]+}", deleteScheduledQueryEndpoint, deleteScheduledQueryRequest{})

	ue.EndingAtVersion("v1").GET("/api/_version_/mobius/global/schedule", getGlobalScheduleEndpoint, getGlobalScheduleRequest{})
	ue.StartingAtVersion("2022-04").GET("/api/_version_/mobius/schedule", getGlobalScheduleEndpoint, getGlobalScheduleRequest{})
	ue.EndingAtVersion("v1").POST("/api/_version_/mobius/global/schedule", globalScheduleQueryEndpoint, globalScheduleQueryRequest{})
	ue.StartingAtVersion("2022-04").POST("/api/_version_/mobius/schedule", globalScheduleQueryEndpoint, globalScheduleQueryRequest{})
	ue.EndingAtVersion("v1").PATCH("/api/_version_/mobius/global/schedule/{id:[0-9]+}", modifyGlobalScheduleEndpoint, modifyGlobalScheduleRequest{})
	ue.StartingAtVersion("2022-04").PATCH("/api/_version_/mobius/schedule/{id:[0-9]+}", modifyGlobalScheduleEndpoint, modifyGlobalScheduleRequest{})
	ue.EndingAtVersion("v1").DELETE("/api/_version_/mobius/global/schedule/{id:[0-9]+}", deleteGlobalScheduleEndpoint, deleteGlobalScheduleRequest{})
	ue.StartingAtVersion("2022-04").DELETE("/api/_version_/mobius/schedule/{id:[0-9]+}", deleteGlobalScheduleEndpoint, deleteGlobalScheduleRequest{})

	// Alias /api/_version_/mobius/team/ -> /api/_version_/mobius/teams/
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/schedule").
		GET("/api/_version_/mobius/teams/{team_id}/schedule", getTeamScheduleEndpoint, getTeamScheduleRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/schedule").
		POST("/api/_version_/mobius/teams/{team_id}/schedule", teamScheduleQueryEndpoint, teamScheduleQueryRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/schedule/{scheduled_query_id}").
		PATCH("/api/_version_/mobius/teams/{team_id}/schedule/{scheduled_query_id}", modifyTeamScheduleEndpoint, modifyTeamScheduleRequest{})
	ue.WithAltPaths("/api/_version_/mobius/team/{team_id}/schedule/{scheduled_query_id}").
		DELETE("/api/_version_/mobius/teams/{team_id}/schedule/{scheduled_query_id}", deleteTeamScheduleEndpoint, deleteTeamScheduleRequest{})

	ue.GET("/api/_version_/mobius/carves", listCarvesEndpoint, listCarvesRequest{})
	ue.GET("/api/_version_/mobius/carves/{id:[0-9]+}", getCarveEndpoint, getCarveRequest{})
	ue.GET("/api/_version_/mobius/carves/{id:[0-9]+}/block/{block_id}", getCarveBlockEndpoint, getCarveBlockRequest{})

	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/macadmins", getMacadminsDataEndpoint, getMacadminsDataRequest{})
	ue.GET("/api/_version_/mobius/macadmins", getAggregatedMacadminsDataEndpoint, getAggregatedMacadminsDataRequest{})

	ue.GET("/api/_version_/mobius/status/result_store", statusResultStoreEndpoint, nil)
	ue.GET("/api/_version_/mobius/status/live_query", statusLiveQueryEndpoint, nil)

	ue.POST("/api/_version_/mobius/scripts/run", runScriptEndpoint, runScriptRequest{})
	ue.POST("/api/_version_/mobius/scripts/run/sync", runScriptSyncEndpoint, runScriptSyncRequest{})
	ue.POST("/api/_version_/mobius/scripts/run/batch", batchScriptRunEndpoint, batchScriptRunRequest{})
	ue.GET("/api/_version_/mobius/scripts/results/{execution_id}", getScriptResultEndpoint, getScriptResultRequest{})
	ue.POST("/api/_version_/mobius/scripts", createScriptEndpoint, createScriptRequest{})
	ue.GET("/api/_version_/mobius/scripts", listScriptsEndpoint, listScriptsRequest{})
	ue.GET("/api/_version_/mobius/scripts/{script_id:[0-9]+}", getScriptEndpoint, getScriptRequest{})
	ue.PATCH("/api/_version_/mobius/scripts/{script_id:[0-9]+}", updateScriptEndpoint, updateScriptRequest{})
	ue.DELETE("/api/_version_/mobius/scripts/{script_id:[0-9]+}", deleteScriptEndpoint, deleteScriptRequest{})
	ue.POST("/api/_version_/mobius/scripts/batch", batchSetScriptsEndpoint, batchSetScriptsRequest{})
	ue.GET("/api/_version_/mobius/scripts/batch/summary/{batch_execution_id:[a-zA-Z0-9-]+}", batchScriptExecutionSummaryEndpoint, batchScriptExecutionSummaryRequest{})

	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/scripts", getHostScriptDetailsEndpoint, getHostScriptDetailsRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/activities/upcoming", listHostUpcomingActivitiesEndpoint, listHostUpcomingActivitiesRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/activities", listHostPastActivitiesEndpoint, listHostPastActivitiesRequest{})
	ue.DELETE("/api/_version_/mobius/hosts/{id:[0-9]+}/activities/upcoming/{activity_id}", cancelHostUpcomingActivityEndpoint, cancelHostUpcomingActivityRequest{})
	ue.POST("/api/_version_/mobius/hosts/{id:[0-9]+}/lock", lockHostEndpoint, lockHostRequest{})
	ue.POST("/api/_version_/mobius/hosts/{id:[0-9]+}/unlock", unlockHostEndpoint, unlockHostRequest{})
	ue.POST("/api/_version_/mobius/hosts/{id:[0-9]+}/wipe", wipeHostEndpoint, wipeHostRequest{})

	// Generative AI
	ue.POST("/api/_version_/mobius/autofill/policy", autofillPoliciesEndpoint, autofillPoliciesRequest{})

	// Secret variables
	ue.PUT("/api/_version_/mobius/spec/secret_variables", secretVariablesEndpoint, secretVariablesRequest{})

	// Scim details
	ue.GET("/api/_version_/mobius/scim/details", getScimDetailsEndpoint, nil)

	// Microsoft Compliance Partner
	ue.POST("/api/_version_/mobius/conditional-access/microsoft", conditionalAccessMicrosoftCreateEndpoint, conditionalAccessMicrosoftCreateRequest{})
	ue.POST("/api/_version_/mobius/conditional-access/microsoft/confirm", conditionalAccessMicrosoftConfirmEndpoint, conditionalAccessMicrosoftConfirmRequest{})
	ue.DELETE("/api/_version_/mobius/conditional-access/microsoft", conditionalAccessMicrosoftDeleteEndpoint, conditionalAccessMicrosoftDeleteRequest{})

	// Only Mobius MDM specific endpoints should be within the root /mdm/ path.
	// NOTE: remember to update
	// `service.mdmConfigurationRequiredEndpoints` when you add an
	// endpoint that's behind the mdmConfiguredMiddleware, this applies
	// both to this set of endpoints and to any public/token-authenticated
	// endpoints using `neMDM` below in this file.
	mdmConfiguredMiddleware := mdmconfigured.NewMDMConfigMiddleware(svc)
	mdmAppleMW := ue.WithCustomMiddleware(mdmConfiguredMiddleware.VerifyAppleMDM())

	// Deprecated: POST /mdm/apple/enqueue is now deprecated, replaced by the
	// platform-agnostic POST /mdm/commands/run. It is still supported
	// indefinitely for backwards compatibility.
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/enqueue", enqueueMDMAppleCommandEndpoint, enqueueMDMAppleCommandRequest{})
	// Deprecated: POST /mdm/apple/commandresults is now deprecated, replaced by the
	// platform-agnostic POST /mdm/commands/commandresults. It is still supported
	// indefinitely for backwards compatibility.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/commandresults", getMDMAppleCommandResultsEndpoint, getMDMAppleCommandResultsRequest{})
	// Deprecated: POST /mdm/apple/commands is now deprecated, replaced by the
	// platform-agnostic POST /mdm/commands/commands. It is still supported
	// indefinitely for backwards compatibility.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/commands", listMDMAppleCommandsEndpoint, listMDMAppleCommandsRequest{})
	// Deprecated: those /mdm/apple/profiles/... endpoints are now deprecated,
	// replaced by the platform-agnostic /mdm/profiles/... It is still supported
	// indefinitely for backwards compatibility.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/profiles/{profile_id:[0-9]+}", getMDMAppleConfigProfileEndpoint, getMDMAppleConfigProfileRequest{})
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/apple/profiles/{profile_id:[0-9]+}", deleteMDMAppleConfigProfileEndpoint, deleteMDMAppleConfigProfileRequest{})
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/profiles", newMDMAppleConfigProfileEndpoint, newMDMAppleConfigProfileRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/profiles", listMDMAppleConfigProfilesEndpoint, listMDMAppleConfigProfilesRequest{})

	// Deprecated: GET /mdm/apple/filevault/summary is now deprecated, replaced by the
	// platform-agnostic GET /mdm/disk_encryption/summary. It is still supported indefinitely
	// for backwards compatibility.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/filevault/summary", getMdmAppleFileVaultSummaryEndpoint, getMDMAppleFileVaultSummaryRequest{})

	// Deprecated: GET /mdm/apple/profiles/summary is now deprecated, replaced by the
	// platform-agnostic GET /mdm/profiles/summary. It is still supported indefinitely
	// for backwards compatibility.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/profiles/summary", getMDMAppleProfilesSummaryEndpoint, getMDMAppleProfilesSummaryRequest{})

	// Deprecated: POST /mdm/apple/enrollment_profile is now deprecated, replaced by the
	// POST /enrollment_profiles/automatic endpoint.
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/enrollment_profile", createMDMAppleSetupAssistantEndpoint, createMDMAppleSetupAssistantRequest{})
	mdmAppleMW.POST("/api/_version_/mobius/enrollment_profiles/automatic", createMDMAppleSetupAssistantEndpoint, createMDMAppleSetupAssistantRequest{})

	// Deprecated: GET /mdm/apple/enrollment_profile is now deprecated, replaced by the
	// GET /enrollment_profiles/automatic endpoint.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/enrollment_profile", getMDMAppleSetupAssistantEndpoint, getMDMAppleSetupAssistantRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/enrollment_profiles/automatic", getMDMAppleSetupAssistantEndpoint, getMDMAppleSetupAssistantRequest{})

	// Deprecated: DELETE /mdm/apple/enrollment_profile is now deprecated, replaced by the
	// DELETE /enrollment_profiles/automatic endpoint.
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/apple/enrollment_profile", deleteMDMAppleSetupAssistantEndpoint, deleteMDMAppleSetupAssistantRequest{})
	mdmAppleMW.DELETE("/api/_version_/mobius/enrollment_profiles/automatic", deleteMDMAppleSetupAssistantEndpoint, deleteMDMAppleSetupAssistantRequest{})

	// TODO: are those undocumented endpoints still needed? I think they were only used
	// by 'mobiuscli apple-mdm' sub-commands.
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/installers", uploadAppleInstallerEndpoint, uploadAppleInstallerRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/installers/{installer_id:[0-9]+}", getAppleInstallerEndpoint, getAppleInstallerDetailsRequest{})
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/apple/installers/{installer_id:[0-9]+}", deleteAppleInstallerEndpoint, deleteAppleInstallerDetailsRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/installers", listMDMAppleInstallersEndpoint, listMDMAppleInstallersRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/devices", listMDMAppleDevicesEndpoint, listMDMAppleDevicesRequest{})

	// Deprecated: GET /mdm/manual_enrollment_profile is now deprecated, replaced by the
	// GET /enrollment_profiles/manual endpoint.
	// Ref: https://github.com/notawar/mobius/issues/16252
	mdmAppleMW.GET("/api/_version_/mobius/mdm/manual_enrollment_profile", getManualEnrollmentProfileEndpoint, getManualEnrollmentProfileRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/enrollment_profiles/manual", getManualEnrollmentProfileEndpoint, getManualEnrollmentProfileRequest{})

	// bootstrap-package routes

	// Deprecated: POST /mdm/bootstrap is now deprecated, replaced by the
	// POST /bootstrap endpoint.
	mdmAppleMW.POST("/api/_version_/mobius/mdm/bootstrap", uploadBootstrapPackageEndpoint, uploadBootstrapPackageRequest{})
	mdmAppleMW.POST("/api/_version_/mobius/bootstrap", uploadBootstrapPackageEndpoint, uploadBootstrapPackageRequest{})

	// Deprecated: GET /mdm/bootstrap/:team_id/metadata is now deprecated, replaced by the
	// GET /bootstrap/:team_id/metadata endpoint.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/bootstrap/{team_id:[0-9]+}/metadata", bootstrapPackageMetadataEndpoint, bootstrapPackageMetadataRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/bootstrap/{team_id:[0-9]+}/metadata", bootstrapPackageMetadataEndpoint, bootstrapPackageMetadataRequest{})

	// Deprecated: DELETE /mdm/bootstrap/:team_id is now deprecated, replaced by the
	// DELETE /bootstrap/:team_id endpoint.
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/bootstrap/{team_id:[0-9]+}", deleteBootstrapPackageEndpoint, deleteBootstrapPackageRequest{})
	mdmAppleMW.DELETE("/api/_version_/mobius/bootstrap/{team_id:[0-9]+}", deleteBootstrapPackageEndpoint, deleteBootstrapPackageRequest{})

	// Deprecated: GET /mdm/bootstrap/summary is now deprecated, replaced by the
	// GET /bootstrap/summary endpoint.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/bootstrap/summary", getMDMAppleBootstrapPackageSummaryEndpoint, getMDMAppleBootstrapPackageSummaryRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/bootstrap/summary", getMDMAppleBootstrapPackageSummaryEndpoint, getMDMAppleBootstrapPackageSummaryRequest{})

	// Deprecated: POST /mdm/apple/bootstrap is now deprecated, replaced by the platform agnostic /mdm/bootstrap
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/bootstrap", uploadBootstrapPackageEndpoint, uploadBootstrapPackageRequest{})
	// Deprecated: GET /mdm/apple/bootstrap/:team_id/metadata is now deprecated, replaced by the platform agnostic /mdm/bootstrap/:team_id/metadata
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/bootstrap/{team_id:[0-9]+}/metadata", bootstrapPackageMetadataEndpoint, bootstrapPackageMetadataRequest{})
	// Deprecated: DELETE /mdm/apple/bootstrap/:team_id is now deprecated, replaced by the platform agnostic /mdm/bootstrap/:team_id
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/apple/bootstrap/{team_id:[0-9]+}", deleteBootstrapPackageEndpoint, deleteBootstrapPackageRequest{})
	// Deprecated: GET /mdm/apple/bootstrap/summary is now deprecated, replaced by the platform agnostic /mdm/bootstrap/summary
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/bootstrap/summary", getMDMAppleBootstrapPackageSummaryEndpoint, getMDMAppleBootstrapPackageSummaryRequest{})

	// host-specific mdm routes

	// Deprecated: PATCH /mdm/hosts/:id/unenroll is now deprecated, replaced by
	// DELETE /hosts/:id/mdm.
	mdmAppleMW.PATCH("/api/_version_/mobius/mdm/hosts/{id:[0-9]+}/unenroll", mdmAppleCommandRemoveEnrollmentProfileEndpoint, mdmAppleCommandRemoveEnrollmentProfileRequest{})
	mdmAppleMW.DELETE("/api/_version_/mobius/hosts/{id:[0-9]+}/mdm", mdmAppleCommandRemoveEnrollmentProfileEndpoint, mdmAppleCommandRemoveEnrollmentProfileRequest{})

	// Deprecated: POST /mdm/hosts/:id/lock is now deprecated, replaced by
	// POST /hosts/:id/lock.
	mdmAppleMW.POST("/api/_version_/mobius/mdm/hosts/{id:[0-9]+}/lock", deviceLockEndpoint, deviceLockRequest{})
	mdmAppleMW.POST("/api/_version_/mobius/mdm/hosts/{id:[0-9]+}/wipe", deviceWipeEndpoint, deviceWipeRequest{})

	// Deprecated: GET /mdm/hosts/:id/profiles is now deprecated, replaced by
	// GET /hosts/:id/configuration_profiles.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/hosts/{id:[0-9]+}/profiles", getHostProfilesEndpoint, getHostProfilesRequest{})
	// TODO: Confirm if response should be updated to include Windows profiles and use mdmAnyMW
	mdmAppleMW.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/configuration_profiles", getHostProfilesEndpoint, getHostProfilesRequest{})

	// Deprecated: PATCH /mdm/apple/setup is now deprecated, replaced by the
	// PATCH /setup_experience endpoint.
	mdmAppleMW.PATCH("/api/_version_/mobius/mdm/apple/setup", updateMDMAppleSetupEndpoint, updateMDMAppleSetupRequest{})
	mdmAppleMW.PATCH("/api/_version_/mobius/setup_experience", updateMDMAppleSetupEndpoint, updateMDMAppleSetupRequest{})

	// Deprecated: GET /mdm/apple is now deprecated, replaced by the
	// GET /apns endpoint.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple", getAppleMDMEndpoint, nil)
	mdmAppleMW.GET("/api/_version_/mobius/apns", getAppleMDMEndpoint, nil)

	// EULA routes

	// Deprecated: POST /mdm/setup/eula is now deprecated, replaced by the
	// POST /setup_experience/eula endpoint.
	mdmAppleMW.POST("/api/_version_/mobius/mdm/setup/eula", createMDMEULAEndpoint, createMDMEULARequest{})
	mdmAppleMW.POST("/api/_version_/mobius/setup_experience/eula", createMDMEULAEndpoint, createMDMEULARequest{})

	// Deprecated: GET /mdm/setup/eula/metadata is now deprecated, replaced by the
	// GET /setup_experience/eula/metadata endpoint.
	mdmAppleMW.GET("/api/_version_/mobius/mdm/setup/eula/metadata", getMDMEULAMetadataEndpoint, getMDMEULAMetadataRequest{})
	mdmAppleMW.GET("/api/_version_/mobius/setup_experience/eula/metadata", getMDMEULAMetadataEndpoint, getMDMEULAMetadataRequest{})

	// Deprecated: DELETE /mdm/setup/eula/:token is now deprecated, replaced by the
	// DELETE /setup_experience/eula/:token endpoint.
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/setup/eula/{token}", deleteMDMEULAEndpoint, deleteMDMEULARequest{})
	mdmAppleMW.DELETE("/api/_version_/mobius/setup_experience/eula/{token}", deleteMDMEULAEndpoint, deleteMDMEULARequest{})

	// Deprecated: POST /mdm/apple/setup/eula is now deprecated, replaced by the platform agnostic /mdm/setup/eula
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/setup/eula", createMDMEULAEndpoint, createMDMEULARequest{})
	// Deprecated: GET /mdm/apple/setup/eula/metadata is now deprecated, replaced by the platform agnostic /mdm/setup/eula/metadata
	mdmAppleMW.GET("/api/_version_/mobius/mdm/apple/setup/eula/metadata", getMDMEULAMetadataEndpoint, getMDMEULAMetadataRequest{})
	// Deprecated: DELETE /mdm/apple/setup/eula/:token is now deprecated, replaced by the platform agnostic /mdm/setup/eula/:token
	mdmAppleMW.DELETE("/api/_version_/mobius/mdm/apple/setup/eula/{token}", deleteMDMEULAEndpoint, deleteMDMEULARequest{})

	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/profiles/preassign", preassignMDMAppleProfileEndpoint, preassignMDMAppleProfileRequest{})
	mdmAppleMW.POST("/api/_version_/mobius/mdm/apple/profiles/match", matchMDMApplePreassignmentEndpoint, matchMDMApplePreassignmentRequest{})

	mdmAnyMW := ue.WithCustomMiddleware(mdmConfiguredMiddleware.VerifyAppleOrWindowsMDM())

	// Deprecated: POST /mdm/commands/run is now deprecated, replaced by the
	// POST /commands/run endpoint.
	mdmAnyMW.POST("/api/_version_/mobius/mdm/commands/run", runMDMCommandEndpoint, runMDMCommandRequest{})
	mdmAnyMW.POST("/api/_version_/mobius/commands/run", runMDMCommandEndpoint, runMDMCommandRequest{})

	// Deprecated: GET /mdm/commandresults is now deprecated, replaced by the
	// GET /commands/results endpoint.
	mdmAnyMW.GET("/api/_version_/mobius/mdm/commandresults", getMDMCommandResultsEndpoint, getMDMCommandResultsRequest{})
	mdmAnyMW.GET("/api/_version_/mobius/commands/results", getMDMCommandResultsEndpoint, getMDMCommandResultsRequest{})

	// Deprecated: GET /mdm/commands is now deprecated, replaced by the
	// GET /commands endpoint.
	mdmAnyMW.GET("/api/_version_/mobius/mdm/commands", listMDMCommandsEndpoint, listMDMCommandsRequest{})
	mdmAnyMW.GET("/api/_version_/mobius/commands", listMDMCommandsEndpoint, listMDMCommandsRequest{})

	// Deprecated: GET /mdm/disk_encryption/summary is now deprecated, replaced by the
	// GET /disk_encryption endpoint.
	ue.GET("/api/_version_/mobius/mdm/disk_encryption/summary", getMDMDiskEncryptionSummaryEndpoint, getMDMDiskEncryptionSummaryRequest{})
	ue.GET("/api/_version_/mobius/disk_encryption", getMDMDiskEncryptionSummaryEndpoint, getMDMDiskEncryptionSummaryRequest{})

	// Deprecated: GET /mdm/hosts/:id/encryption_key is now deprecated, replaced by
	// GET /hosts/:id/encryption_key.
	ue.GET("/api/_version_/mobius/mdm/hosts/{id:[0-9]+}/encryption_key", getHostEncryptionKey, getHostEncryptionKeyRequest{})
	ue.GET("/api/_version_/mobius/hosts/{id:[0-9]+}/encryption_key", getHostEncryptionKey, getHostEncryptionKeyRequest{})

	// Deprecated: GET /mdm/profiles/summary is now deprecated, replaced by the
	// GET /configuration_profiles/summary endpoint.
	ue.GET("/api/_version_/mobius/mdm/profiles/summary", getMDMProfilesSummaryEndpoint, getMDMProfilesSummaryRequest{})
	ue.GET("/api/_version_/mobius/configuration_profiles/summary", getMDMProfilesSummaryEndpoint, getMDMProfilesSummaryRequest{})

	// Deprecated: GET /mdm/profiles/:profile_uuid is now deprecated, replaced by
	// GET /configuration_profiles/:profile_uuid.
	mdmAnyMW.GET("/api/_version_/mobius/mdm/profiles/{profile_uuid}", getMDMConfigProfileEndpoint, getMDMConfigProfileRequest{})
	mdmAnyMW.GET("/api/_version_/mobius/configuration_profiles/{profile_uuid}", getMDMConfigProfileEndpoint, getMDMConfigProfileRequest{})

	// Deprecated: DELETE /mdm/profiles/:profile_uuid is now deprecated, replaced by
	// DELETE /configuration_profiles/:profile_uuid.
	mdmAnyMW.DELETE("/api/_version_/mobius/mdm/profiles/{profile_uuid}", deleteMDMConfigProfileEndpoint, deleteMDMConfigProfileRequest{})
	mdmAnyMW.DELETE("/api/_version_/mobius/configuration_profiles/{profile_uuid}", deleteMDMConfigProfileEndpoint, deleteMDMConfigProfileRequest{})

	// Deprecated: GET /mdm/profiles is now deprecated, replaced by the
	// GET /configuration_profiles endpoint.
	mdmAnyMW.GET("/api/_version_/mobius/mdm/profiles", listMDMConfigProfilesEndpoint, listMDMConfigProfilesRequest{})
	mdmAnyMW.GET("/api/_version_/mobius/configuration_profiles", listMDMConfigProfilesEndpoint, listMDMConfigProfilesRequest{})

	// Deprecated: POST /mdm/profiles is now deprecated, replaced by the
	// POST /configuration_profiles endpoint.
	mdmAnyMW.POST("/api/_version_/mobius/mdm/profiles", newMDMConfigProfileEndpoint, newMDMConfigProfileRequest{})
	mdmAnyMW.POST("/api/_version_/mobius/configuration_profiles", newMDMConfigProfileEndpoint, newMDMConfigProfileRequest{})

	// Deprecated: POST /hosts/{host_id:[0-9]+}/configuration_profiles/resend/{profile_uuid} is now deprecated, replaced by the
	// POST /hosts/{host_id:[0-9]+}/configuration_profiles/{profile_uuid}/resend endpoint.
	mdmAnyMW.POST("/api/_version_/mobius/hosts/{host_id:[0-9]+}/configuration_profiles/resend/{profile_uuid}", resendHostMDMProfileEndpoint, resendHostMDMProfileRequest{})
	mdmAnyMW.POST("/api/_version_/mobius/hosts/{host_id:[0-9]+}/configuration_profiles/{profile_uuid}/resend", resendHostMDMProfileEndpoint, resendHostMDMProfileRequest{})
	mdmAnyMW.POST("/api/_version_/mobius/configuration_profiles/resend/batch", batchResendMDMProfileToHostsEndpoint, batchResendMDMProfileToHostsRequest{})
	mdmAnyMW.GET("/api/_version_/mobius/configuration_profiles/{profile_uuid}/status", getMDMConfigProfileStatusEndpoint, getMDMConfigProfileStatusRequest{})

	// Deprecated: PATCH /mdm/apple/settings is deprecated, replaced by POST /disk_encryption.
	// It was only used to set disk encryption.
	mdmAnyMW.PATCH("/api/_version_/mobius/mdm/apple/settings", updateMDMAppleSettingsEndpoint, updateMDMAppleSettingsRequest{})
	ue.POST("/api/_version_/mobius/disk_encryption", updateDiskEncryptionEndpoint, updateDiskEncryptionRequest{})

	// the following set of mdm endpoints must always be accessible (even
	// if MDM is not configured) as it bootstraps the setup of MDM
	// (generates CSR request for APNs, plus the SCEP and ABM keypairs).
	// Deprecated: this endpoint shouldn't be used anymore in favor of the
	// new flow described in https://github.com/notawar/mobius/issues/10383
	ue.POST("/api/_version_/mobius/mdm/apple/request_csr", requestMDMAppleCSREndpoint, requestMDMAppleCSRRequest{})
	// Deprecated: this endpoint shouldn't be used anymore in favor of the
	// new flow described in https://github.com/notawar/mobius/issues/10383
	ue.POST("/api/_version_/mobius/mdm/apple/dep/key_pair", newMDMAppleDEPKeyPairEndpoint, nil)
	ue.GET("/api/_version_/mobius/mdm/apple/abm_public_key", generateABMKeyPairEndpoint, nil)
	ue.POST("/api/_version_/mobius/abm_tokens", uploadABMTokenEndpoint, uploadABMTokenRequest{})
	ue.DELETE("/api/_version_/mobius/abm_tokens/{id:[0-9]+}", deleteABMTokenEndpoint, deleteABMTokenRequest{})
	ue.GET("/api/_version_/mobius/abm_tokens", listABMTokensEndpoint, nil)
	ue.GET("/api/_version_/mobius/abm_tokens/count", countABMTokensEndpoint, nil)
	ue.PATCH("/api/_version_/mobius/abm_tokens/{id:[0-9]+}/teams", updateABMTokenTeamsEndpoint, updateABMTokenTeamsRequest{})
	ue.PATCH("/api/_version_/mobius/abm_tokens/{id:[0-9]+}/renew", renewABMTokenEndpoint, renewABMTokenRequest{})

	ue.GET("/api/_version_/mobius/mdm/apple/request_csr", getMDMAppleCSREndpoint, getMDMAppleCSRRequest{})
	ue.POST("/api/_version_/mobius/mdm/apple/apns_certificate", uploadMDMAppleAPNSCertEndpoint, uploadMDMAppleAPNSCertRequest{})
	ue.DELETE("/api/_version_/mobius/mdm/apple/apns_certificate", deleteMDMAppleAPNSCertEndpoint, deleteMDMAppleAPNSCertRequest{})

	// VPP Tokens
	ue.GET("/api/_version_/mobius/vpp_tokens", getVPPTokens, getVPPTokensRequest{})
	ue.POST("/api/_version_/mobius/vpp_tokens", uploadVPPTokenEndpoint, uploadVPPTokenRequest{})
	ue.PATCH("/api/_version_/mobius/vpp_tokens/{id}/teams", patchVPPTokensTeams, patchVPPTokensTeamsRequest{})
	ue.PATCH("/api/_version_/mobius/vpp_tokens/{id}/renew", patchVPPTokenRenewEndpoint, patchVPPTokenRenewRequest{})
	ue.DELETE("/api/_version_/mobius/vpp_tokens/{id}", deleteVPPToken, deleteVPPTokenRequest{})

	// Batch VPP Associations
	ue.POST("/api/_version_/mobius/software/app_store_apps/batch", batchAssociateAppStoreAppsEndpoint, batchAssociateAppStoreAppsRequest{})

	// Deprecated: GET /mdm/apple_bm is now deprecated, replaced by the
	// GET /abm endpoint.
	ue.GET("/api/_version_/mobius/mdm/apple_bm", getAppleBMEndpoint, nil)
	// Deprecated: GET /abm is now deprecated, replaced by the GET /abm_tokens endpoint.
	ue.GET("/api/_version_/mobius/abm", getAppleBMEndpoint, nil)

	// Deprecated: POST /mdm/apple/profiles/batch is now deprecated, replaced by the
	// platform-agnostic POST /mdm/profiles/batch. It is still supported
	// indefinitely for backwards compatibility.
	//
	// batch-apply is accessible even though MDM is not enabled, it needs
	// to support the case where `mobiusclii get config`'s output is used as
	// input to `mobiusclii apply`
	ue.POST("/api/_version_/mobius/mdm/apple/profiles/batch", batchSetMDMAppleProfilesEndpoint, batchSetMDMAppleProfilesRequest{})

	// batch-apply is accessible even though MDM is not enabled, it needs
	// to support the case where `mobiusclii get config`'s output is used as
	// input to `mobiusclii apply`
	ue.POST("/api/_version_/mobius/mdm/profiles/batch", batchSetMDMProfilesEndpoint, batchSetMDMProfilesRequest{})

	errorLimiter := ratelimit.NewErrorMiddleware(limitStore)

	// device-authenticated endpoints
	de := newDeviceAuthenticatedEndpointer(svc, logger, opts, r, apiVersions...)
	// We allow a quota of 720 because in the onboarding of a Mobius Desktop takes a few tries until it authenticates
	// properly
	desktopQuota := throttled.RateQuota{MaxRate: throttled.PerHour(720), MaxBurst: desktopRateLimitMaxBurst}
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_host", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}", getDeviceHostEndpoint, getDeviceHostRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_mobius_desktop", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/desktop", getMobiusDesktopEndpoint, getMobiusDesktopRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("ping_device_auth", desktopQuota),
	).HEAD("/api/_version_/mobius/device/{token}/ping", devicePingEndpoint, deviceAuthPingRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("refetch_device_host", desktopQuota),
	).POST("/api/_version_/mobius/device/{token}/refetch", refetchDeviceHostEndpoint, refetchDeviceHostRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_mapping", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/device_mapping", listDeviceHostDeviceMappingEndpoint, listDeviceHostDeviceMappingRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_macadmins", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/macadmins", getDeviceMacadminsDataEndpoint, getDeviceMacadminsDataRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_policies", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/policies", listDevicePoliciesEndpoint, listDevicePoliciesRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_transparency", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/transparency", transparencyURL, transparencyURLRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("send_device_error", desktopQuota),
	).POST("/api/_version_/mobius/device/{token}/debug/errors", mobiusdError, mobiusdErrorRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_software", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/software", getDeviceSoftwareEndpoint, getDeviceSoftwareRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("install_self_service", desktopQuota),
	).POST("/api/_version_/mobius/device/{token}/software/install/{software_title_id}", submitSelfServiceSoftwareInstall, mobiusSelfServiceSoftwareInstallRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("uninstall_self_service", desktopQuota),
	).POST("/api/_version_/mobius/device/{token}/software/uninstall/{software_title_id}", submitDeviceSoftwareUninstall, mobiusDeviceSoftwareUninstallRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_software_install_results", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/software/install/{install_uuid}/results", getDeviceSoftwareInstallResultsEndpoint,
		getDeviceSoftwareInstallResultsRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_software_uninstall_results", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/software/uninstall/{execution_id}/results", getDeviceSoftwareUninstallResultsEndpoint, getDeviceSoftwareUninstallResultsRequest{})
	de.WithCustomMiddleware(
		errorLimiter.Limit("get_device_certificates", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/certificates", listDeviceCertificatesEndpoint, listDeviceCertificatesRequest{})

	// mdm-related endpoints available via device authentication
	demdm := de.WithCustomMiddleware(mdmConfiguredMiddleware.VerifyAppleMDM())
	demdm.WithCustomMiddleware(
		errorLimiter.Limit("get_device_mdm", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/mdm/apple/manual_enrollment_profile", getDeviceMDMManualEnrollProfileEndpoint, getDeviceMDMManualEnrollProfileRequest{})
	demdm.WithCustomMiddleware(
		errorLimiter.Limit("get_device_software_mdm_command_results", desktopQuota),
	).GET("/api/_version_/mobius/device/{token}/software/commands/{command_uuid}/results", getDeviceMDMCommandResultsEndpoint,
		getDeviceMDMCommandResultsRequest{})

	demdm.WithCustomMiddleware(
		errorLimiter.Limit("post_device_migrate_mdm", desktopQuota),
	).POST("/api/_version_/mobius/device/{token}/migrate_mdm", migrateMDMDeviceEndpoint, deviceMigrateMDMRequest{})

	de.WithCustomMiddleware(
		errorLimiter.Limit("post_device_trigger_linux_escrow", desktopQuota),
	).POST("/api/_version_/mobius/device/{token}/mdm/linux/trigger_escrow", triggerLinuxDiskEncryptionEscrowEndpoint, triggerLinuxDiskEncryptionEscrowRequest{})

	// host-authenticated endpoints
	he := newHostAuthenticatedEndpointer(svc, logger, opts, r, apiVersions...)

	// Note that the /osquery/ endpoints are *not* versioned, i.e. there is no
	// `_version_` placeholder in the path. This is deliberate, see
	// https://github.com/notawar/mobius/pull/4731#discussion_r838931732 For now
	// we add an alias to `/api/v1/osquery` so that it is backwards compatible,
	// but even that `v1` is *not* part of the standard versioning, it will still
	// work even after we remove support for the `v1` version for the rest of the
	// API. This allows us to deprecate osquery endpoints separately.
	he.WithAltPaths("/api/v1/osquery/config").
		POST("/api/osquery/config", getClientConfigEndpoint, getClientConfigRequest{})
	he.WithAltPaths("/api/v1/osquery/distributed/read").
		POST("/api/osquery/distributed/read", getDistributedQueriesEndpoint, getDistributedQueriesRequest{})
	he.WithAltPaths("/api/v1/osquery/distributed/write").
		POST("/api/osquery/distributed/write", submitDistributedQueryResultsEndpoint, submitDistributedQueryResultsRequestShim{})
	he.WithAltPaths("/api/v1/osquery/carve/begin").
		POST("/api/osquery/carve/begin", carveBeginEndpoint, carveBeginRequest{})
	he.WithAltPaths("/api/v1/osquery/log").
		POST("/api/osquery/log", submitLogsEndpoint, submitLogsRequest{})
	he.WithAltPaths("/api/v1/osquery/yara/{name}").
		POST("/api/osquery/yara/{name}", getYaraEndpoint, getYaraRequest{})

	// ORBIT ENDPOINTS REMOVED - API-FIRST ARCHITECTURE
	// All orbit endpoints have been removed as part of the transition to pure Go backend with API-first architecture.
	// The frontend will be rebuilt as a separate application consuming REST APIs directly.
	//
	// Previously removed endpoints:
	// - /api/mobius/orbit/device_token
	// - /api/mobius/orbit/config
	// - /api/mobius/orbit/scripts/request
	// - /api/mobius/orbit/scripts/result
	// - /api/mobius/orbit/device_mapping
	// - /api/mobius/orbit/software_install/result
	// - /api/mobius/orbit/software_install/package
	// - /api/mobius/orbit/software_install/details
	// - /api/mobius/orbit/setup_experience/status
	// - /api/mobius/orbit/disk_encryption_key
	// - /api/mobius/orbit/luks_data

	// unauthenticated endpoints - most of those are either login-related,
	// invite-related or host-enrolling. So they typically do some kind of
	// one-time authentication by verifying that a valid secret token is provided
	// with the request.
	ne := newNoAuthEndpointer(svc, opts, r, apiVersions...)
	ne.WithAltPaths("/api/v1/osquery/enroll").
		POST("/api/osquery/enroll", enrollAgentEndpoint, enrollAgentRequest{})

	// These endpoint are token authenticated.
	// NOTE: remember to update
	// `service.mdmConfigurationRequiredEndpoints` when you add an
	// endpoint that's behind the mdmConfiguredMiddleware, this applies
	// both to this set of endpoints and to any user authenticated
	// endpoints using `mdmAppleMW.*` above in this file.
	neAppleMDM := ne.WithCustomMiddleware(mdmConfiguredMiddleware.VerifyAppleMDM())
	neAppleMDM.GET(apple_mdm.EnrollPath, mdmAppleEnrollEndpoint, mdmAppleEnrollRequest{})
	neAppleMDM.POST(apple_mdm.EnrollPath, mdmAppleEnrollEndpoint, mdmAppleEnrollRequest{})
	neAppleMDM.GET(apple_mdm.InstallerPath, mdmAppleGetInstallerEndpoint, mdmAppleGetInstallerRequest{})
	neAppleMDM.HEAD(apple_mdm.InstallerPath, mdmAppleHeadInstallerEndpoint, mdmAppleHeadInstallerRequest{})
	neAppleMDM.POST("/api/_version_/mobius/ota_enrollment", mdmAppleOTAEndpoint, mdmAppleOTARequest{})

	// Deprecated: GET /mdm/bootstrap is now deprecated, replaced by the
	// GET /bootstrap endpoint.
	neAppleMDM.GET("/api/_version_/mobius/mdm/bootstrap", downloadBootstrapPackageEndpoint, downloadBootstrapPackageRequest{})
	neAppleMDM.GET("/api/_version_/mobius/bootstrap", downloadBootstrapPackageEndpoint, downloadBootstrapPackageRequest{})

	// Deprecated: GET /mdm/apple/bootstrap is now deprecated, replaced by the platform agnostic /mdm/bootstrap
	neAppleMDM.GET("/api/_version_/mobius/mdm/apple/bootstrap", downloadBootstrapPackageEndpoint, downloadBootstrapPackageRequest{})

	// Deprecated: GET /mdm/setup/eula/:token is now deprecated, replaced by the
	// GET /setup_experience/eula/:token endpoint.
	neAppleMDM.GET("/api/_version_/mobius/mdm/setup/eula/{token}", getMDMEULAEndpoint, getMDMEULARequest{})
	neAppleMDM.GET("/api/_version_/mobius/setup_experience/eula/{token}", getMDMEULAEndpoint, getMDMEULARequest{})

	// Deprecated: GET /mdm/apple/setup/eula/:token is now deprecated, replaced by the platform agnostic /mdm/setup/eula/:token
	neAppleMDM.GET("/api/_version_/mobius/mdm/apple/setup/eula/{token}", getMDMEULAEndpoint, getMDMEULARequest{})

	// Get OTA profile
	neAppleMDM.GET("/api/_version_/mobius/enrollment_profiles/ota", getOTAProfileEndpoint, getOTAProfileRequest{})

	// These endpoint are used by Microsoft devices during MDM device enrollment phase
	neWindowsMDM := ne.WithCustomMiddleware(mdmConfiguredMiddleware.VerifyWindowsMDM())

	// Microsoft MS-MDE2 Endpoints
	// This endpoint is unauthenticated and is used by Microsoft devices to discover the MDM server endpoints
	neWindowsMDM.POST(microsoft_mdm.MDE2DiscoveryPath, mdmMicrosoftDiscoveryEndpoint, SoapRequestContainer{})

	// This endpoint is unauthenticated and is used by Microsoft devices to retrieve the opaque STS auth token
	neWindowsMDM.GET(microsoft_mdm.MDE2AuthPath, mdmMicrosoftAuthEndpoint, SoapRequestContainer{})

	// This endpoint is authenticated using the BinarySecurityToken header field
	neWindowsMDM.POST(microsoft_mdm.MDE2PolicyPath, mdmMicrosoftPolicyEndpoint, SoapRequestContainer{})

	// This endpoint is authenticated using the BinarySecurityToken header field
	neWindowsMDM.POST(microsoft_mdm.MDE2EnrollPath, mdmMicrosoftEnrollEndpoint, SoapRequestContainer{})

	// This endpoint is unauthenticated for now
	// It should be authenticated through TLS headers once proper implementation is in place
	neWindowsMDM.POST(microsoft_mdm.MDE2ManagementPath, mdmMicrosoftManagementEndpoint, SyncMLReqMsgContainer{})

	// This endpoint is unauthenticated and is used by to retrieve the MDM enrollment Terms of Use
	neWindowsMDM.GET(microsoft_mdm.MDE2TOSPath, mdmMicrosoftTOSEndpoint, MDMWebContainer{})

	// ORBIT ENROLLMENT ENDPOINT REMOVED - API-FIRST ARCHITECTURE
	// Orbit enrollment has been removed as part of the transition to API-first architecture
	// ne.POST("/api/mobius/orbit/enroll", enrollOrbitEndpoint, EnrollOrbitRequest{})

	// For some reason osquery does not provide a node key with the block data.
	// Instead the carve session ID should be verified in the service method.
	ne.WithAltPaths("/api/v1/osquery/carve/block").
		POST("/api/osquery/carve/block", carveBlockEndpoint, carveBlockRequest{})

	ne.GET("/api/_version_/mobius/software/titles/{title_id:[0-9]+}/package/token/{token}", downloadSoftwareInstallerEndpoint,
		downloadSoftwareInstallerRequest{})

	ne.POST("/api/_version_/mobius/perform_required_password_reset", performRequiredPasswordResetEndpoint, performRequiredPasswordResetRequest{})
	ne.POST("/api/_version_/mobius/users", createUserFromInviteEndpoint, createUserRequest{})
	ne.GET("/api/_version_/mobius/invites/{token}", verifyInviteEndpoint, verifyInviteRequest{})
	ne.POST("/api/_version_/mobius/reset_password", resetPasswordEndpoint, resetPasswordRequest{})
	ne.POST("/api/_version_/mobius/logout", logoutEndpoint, nil)
	ne.POST("/api/v1/mobius/sso", initiateSSOEndpoint, initiateSSORequest{})
	ne.POST("/api/v1/mobius/sso/callback", makeCallbackSSOEndpoint(config.Server.URLPrefix), callbackSSORequest{})
	ne.GET("/api/v1/mobius/sso", settingsSSOEndpoint, nil)

	// the websocket distributed query results endpoint is a bit different - the
	// provided path is a prefix, not an exact match, and it is not a go-kit
	// endpoint but a raw http.Handler. It uses the NoAuthEndpointer because
	// authentication is done when the websocket session is established, inside
	// the handler.
	ne.UsePathPrefix().PathHandler("GET", "/api/_version_/mobius/results/",
		makeStreamDistributedQueryCampaignResultsHandler(config.Server, svc, logger))

	quota := throttled.RateQuota{MaxRate: throttled.PerHour(10), MaxBurst: forgotPasswordRateLimitMaxBurst}
	limiter := ratelimit.NewMiddleware(limitStore)
	ne.
		WithCustomMiddleware(limiter.Limit("forgot_password", quota)).
		POST("/api/_version_/mobius/forgot_password", forgotPasswordEndpoint, forgotPasswordRequest{})

	// By default, MDM SSO shares the login rate limit bucket; if MDM SSO limit is overridden, MDM SSO gets its
	// own rate limit bucket.
	loginRateLimit := throttled.PerMin(10)
	if extra.loginRateLimit != nil {
		loginRateLimit = *extra.loginRateLimit
	}
	loginLimiter := limiter.Limit("login", throttled.RateQuota{MaxRate: loginRateLimit, MaxBurst: 9})
	mdmSsoLimiter := loginLimiter
	if extra.mdmSsoRateLimit != nil {
		mdmSsoLimiter = limiter.Limit("mdm_sso", throttled.RateQuota{MaxRate: *extra.mdmSsoRateLimit, MaxBurst: 9})
	}

	ne.WithCustomMiddleware(loginLimiter).
		POST("/api/_version_/mobius/login", loginEndpoint, contract.LoginRequest{})
	ne.WithCustomMiddleware(limiter.Limit("mfa", throttled.RateQuota{MaxRate: loginRateLimit, MaxBurst: 9})).
		POST("/api/_version_/mobius/sessions", sessionCreateEndpoint, sessionCreateRequest{})

	ne.HEAD("/api/mobius/device/ping", devicePingEndpoint, devicePingRequest{})

	// ORBIT PING ENDPOINT REMOVED - API-FIRST ARCHITECTURE
	// ne.HEAD("/api/mobius/orbit/ping", orbitPingEndpoint, orbitPingRequest{})

	// This is a callback endpoint for calendar integration -- it is called to notify an event change in a user calendar
	ne.POST("/api/_version_/mobius/calendar/webhook/{event_uuid}", calendarWebhookEndpoint, calendarWebhookRequest{})

	neAppleMDM.WithCustomMiddleware(mdmSsoLimiter).
		POST("/api/_version_/mobius/mdm/sso", initiateMDMAppleSSOEndpoint, initiateMDMAppleSSORequest{})
	neAppleMDM.WithCustomMiddleware(mdmSsoLimiter).
		POST("/api/_version_/mobius/mdm/sso/callback", callbackMDMAppleSSOEndpoint, callbackMDMAppleSSORequest{})
}

// WithSetup is an http middleware that checks if setup procedures have been completed.
// If setup hasn't been completed it serves the API with a setup middleware.
// If the server is already configured, the default API handler is exposed.
func WithSetup(svc mobius.Service, logger kitlog.Logger, next http.Handler) http.HandlerFunc {
	rxOsquery := regexp.MustCompile(`^/api/[^/]+/osquery`)
	return func(w http.ResponseWriter, r *http.Request) {
		configRouter := http.NewServeMux()
		srv := kithttp.NewServer(
			makeSetupEndpoint(svc, logger),
			decodeSetupRequest,
			encodeResponse,
		)
		// NOTE: support setup on both /v1/ and version-less, in the future /v1/
		// will be dropped.
		configRouter.Handle("/api/v1/setup", srv)
		configRouter.Handle("/api/setup", srv)

		// whitelist osqueryd endpoints
		if rxOsquery.MatchString(r.URL.Path) {
			next.ServeHTTP(w, r)
			return
		}
		requireSetup, err := svc.SetupRequired(context.Background())
		if err != nil {
			logger.Log("msg", "fetching setup info from db", "err", err)
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		if requireSetup {
			configRouter.ServeHTTP(w, r)
			return
		}
		next.ServeHTTP(w, r)
	}
}

// RedirectLoginToSetup detects if the setup endpoint should be used. If setup is required it redirect all
// frontend urls to /setup, otherwise the frontend router is used.
func RedirectLoginToSetup(svc mobius.Service, logger kitlog.Logger, next http.Handler, urlPrefix string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		redirect := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Path == "/setup" {
				next.ServeHTTP(w, r)
				return
			}
			newURL := r.URL
			newURL.Path = urlPrefix + "/setup"
			http.Redirect(w, r, newURL.String(), http.StatusTemporaryRedirect)
		})

		setupRequired, err := svc.SetupRequired(context.Background())
		if err != nil {
			logger.Log("msg", "fetching setupinfo from db", "err", err)
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		if setupRequired {
			redirect.ServeHTTP(w, r)
			return
		}
		RedirectSetupToLogin(svc, logger, next, urlPrefix).ServeHTTP(w, r)
	}
}

// RedirectSetupToLogin forces the /setup path to be redirected to login. This middleware is used after
// the app has been setup.
func RedirectSetupToLogin(svc mobius.Service, logger kitlog.Logger, next http.Handler, urlPrefix string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/setup" {
			newURL := r.URL
			newURL.Path = urlPrefix + "/login"
			http.Redirect(w, r, newURL.String(), http.StatusTemporaryRedirect)
			return
		}
		next.ServeHTTP(w, r)
	}
}

// RegisterAppleMDMProtocolServices registers the HTTP handlers that serve
// the MDM services to Apple devices.
func RegisterAppleMDMProtocolServices(
	mux *http.ServeMux,
	scepConfig config.MDMConfig,
	mdmStorage mobius.MDMAppleStore,
	scepStorage scep_depot.Depot,
	logger kitlog.Logger,
	checkinAndCommandService nanomdm_service.CheckinAndCommandService,
	ddmService nanomdm_service.DeclarativeManagement,
	profileService nanomdm_service.ProfileService,
) error {
	if err := registerSCEP(mux, scepConfig, scepStorage, mdmStorage, logger); err != nil {
		return fmt.Errorf("scep: %w", err)
	}
	if err := registerMDM(mux, mdmStorage, checkinAndCommandService, ddmService, profileService, logger); err != nil {
		return fmt.Errorf("mdm: %w", err)
	}
	return nil
}

// registerSCEP registers the HTTP handler for SCEP service needed for enrollment to MDM.
// Returns the SCEP CA certificate that can be used by verifiers.
func registerSCEP(
	mux *http.ServeMux,
	scepConfig config.MDMConfig,
	scepStorage scep_depot.Depot,
	mdmStorage mobius.MDMAppleStore,
	logger kitlog.Logger,
) error {
	var signer scepserver.CSRSignerContext = scepserver.SignCSRAdapter(scep_depot.NewSigner(
		scepStorage,
		scep_depot.WithValidityDays(scepConfig.AppleSCEPSignerValidityDays),
		scep_depot.WithAllowRenewalDays(scepConfig.AppleSCEPSignerAllowRenewalDays),
	))
	assets, err := mdmStorage.GetAllMDMConfigAssetsByName(context.Background(), []mobius.MDMAssetName{mobius.MDMAssetSCEPChallenge}, nil)
	if err != nil {
		return fmt.Errorf("retrieving SCEP challenge: %w", err)
	}

	scepChallenge := string(assets[mobius.MDMAssetSCEPChallenge].Value)
	signer = scepserver.StaticChallengeMiddleware(scepChallenge, signer)
	scepService := NewSCEPService(
		mdmStorage,
		signer,
		kitlog.With(logger, "component", "mdm-apple-scep"),
	)

	scepLogger := kitlog.With(logger, "component", "http-mdm-apple-scep")
	e := scepserver.MakeServerEndpoints(scepService)
	e.GetEndpoint = scepserver.EndpointLoggingMiddleware(scepLogger)(e.GetEndpoint)
	e.PostEndpoint = scepserver.EndpointLoggingMiddleware(scepLogger)(e.PostEndpoint)
	scepHandler := scepserver.MakeHTTPHandler(e, scepService, scepLogger)
	mux.Handle(apple_mdm.SCEPPath, scepHandler)
	return nil
}

func RegisterSCEPProxy(
	rootMux *http.ServeMux,
	ds mobius.Datastore,
	logger kitlog.Logger,
	timeout *time.Duration,
) error {
	// Enterprise SCEP service removed - return error
	return fmt.Errorf("SCEP functionality requires enterprise features")
}

// NanoMDMLogger is a logger adapter for nanomdm.
type NanoMDMLogger struct {
	logger kitlog.Logger
}

func NewNanoMDMLogger(logger kitlog.Logger) *NanoMDMLogger {
	return &NanoMDMLogger{
		logger: logger,
	}
}

func (l *NanoMDMLogger) Info(keyvals ...interface{}) {
	level.Info(l.logger).Log(keyvals...)
}

func (l *NanoMDMLogger) Debug(keyvals ...interface{}) {
	level.Debug(l.logger).Log(keyvals...)
}

func (l *NanoMDMLogger) With(keyvals ...interface{}) nanomdm_log.Logger {
	newLogger := kitlog.With(l.logger, keyvals...)
	return &NanoMDMLogger{
		logger: newLogger,
	}
}

// registerMDM registers the HTTP handlers that serve core MDM services (like checking in for MDM commands).
func registerMDM(
	mux *http.ServeMux,
	mdmStorage mobius.MDMAppleStore,
	checkinAndCommandService nanomdm_service.CheckinAndCommandService,
	ddmService nanomdm_service.DeclarativeManagement,
	profileService nanomdm_service.ProfileService,
	logger kitlog.Logger,
) error {
	certVerifier := mdmcrypto.NewSCEPVerifier(mdmStorage)
	mdmLogger := NewNanoMDMLogger(kitlog.With(logger, "component", "http-mdm-apple-mdm"))

	// As usual, handlers are applied from bottom to top:
	// 1. Extract and verify MDM signature.
	// 2. Verify signer certificate with CA.
	// 3. Verify new or enrolled certificate (certauth.CertAuth which wraps the MDM service).
	// 4. Pass a copy of the request to Mobius middleware that ingests new hosts from pending MDM
	// enrollments and updates the Mobius hosts table accordingly with the UDID and serial number of
	// the device.
	// 5. Run actual MDM service operation (checkin handler or command and results handler).
	coreMDMService := nanomdm.New(mdmStorage, nanomdm.WithLogger(mdmLogger), nanomdm.WithDeclarativeManagement(ddmService),
		nanomdm.WithProfileService(profileService))
	// NOTE: it is critical that the coreMDMService runs first, as the first
	// service in the multi-service feature is run to completion _before_ running
	// the other ones in parallel. This way, subsequent services have access to
	// the result of the core service, e.g. the device is enrolled, etc.
	var mdmService nanomdm_service.CheckinAndCommandService = multi.New(mdmLogger, coreMDMService, checkinAndCommandService)

	mdmService = certauth.New(mdmService, mdmStorage, certauth.WithLogger(mdmLogger.With("handler", "cert-auth")))
	var mdmHandler http.Handler = httpmdm.CheckinAndCommandHandler(mdmService, mdmLogger.With("handler", "checkin-command"))
	verifyDisable, exists := os.LookupEnv("MOBIUS_MDM_APPLE_SCEP_VERIFY_DISABLE")
	if exists && (strings.EqualFold(verifyDisable, "true") || verifyDisable == "1") {
		level.Info(logger).Log("msg",
			"disabling verification of macOS SCEP certificates as MOBIUS_MDM_APPLE_SCEP_VERIFY_DISABLE is set to true")
	} else {
		mdmHandler = httpmdm.CertVerifyMiddleware(mdmHandler, certVerifier, mdmLogger.With("handler", "cert-verify"))
	}
	mdmHandler = httpmdm.CertExtractMdmSignatureMiddleware(mdmHandler, httpmdm.MdmSignatureVerifierFunc(cryptoutil.VerifyMdmSignature),
		httpmdm.SigLogWithLogger(mdmLogger.With("handler", "cert-extract")))
	mux.Handle(apple_mdm.MDMPath, mdmHandler)
	return nil
}

func WithMDMEnrollmentMiddleware(svc mobius.Service, logger kitlog.Logger, next http.Handler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/mdm/sso" {
			// TODO: redirects for non-SSO config web url?
			next.ServeHTTP(w, r)
			return
		}

		// if x-apple-aspen-deviceinfo custom header is present, we need to check for minimum os version
		di := r.Header.Get("x-apple-aspen-deviceinfo")
		if di != "" {
			parsed, err := apple_mdm.ParseDeviceinfo(di, false) // FIXME: use verify=true when we have better parsing for various Apple certs (https://github.com/notawar/mobius/issues/20879)
			if err != nil {
				// just log the error and continue to next
				level.Error(logger).Log("msg", "parsing x-apple-aspen-deviceinfo", "err", err)
				next.ServeHTTP(w, r)
				return
			}

			// TODO: skip os version check if deviceinfo query param is present? or find another way
			// to avoid polling the DB and Apple endpoint twice for each enrollment.

			sur, err := svc.CheckMDMAppleEnrollmentWithMinimumOSVersion(r.Context(), parsed)
			if err != nil {
				// just log the error and continue to next
				level.Error(logger).Log("msg", "checking minimum os version for mdm", "err", err)
				next.ServeHTTP(w, r)
				return
			}

			if sur != nil {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusForbidden)
				if err := json.NewEncoder(w).Encode(sur); err != nil {
					level.Error(logger).Log("msg", "failed to encode software update required", "err", err)
					http.Redirect(w, r, r.URL.String()+"?error=true", http.StatusSeeOther)
				}
				return
			}

			// TODO: Do non-Apple devices ever use this route? If so, we probably need to change the
			// approach below so we don't endlessly redirect non-Apple clients to the same URL.

			// if we get here, the minimum os version is satisfied, so we continue with SSO flow
			q := r.URL.Query()
			v, ok := q["deviceinfo"]
			if !ok || len(v) == 0 {
				// If the deviceinfo query param is empty, we add the deviceinfo to the URL and
				// redirect.
				//
				// Note: We'll apply this redirect only if query params are empty because want to
				// redirect to the same URL with added query params after parsing the x-apple-aspen-deviceinfo
				// header. Whenever we see a request with any query params already present, we'll
				// skip this step and just continue to the next handler.
				newURL := *r.URL
				q.Set("deviceinfo", di)
				newURL.RawQuery = q.Encode()
				level.Info(logger).Log("msg", "handling mdm sso: redirect with deviceinfo", "host_uuid", parsed.UDID, "serial", parsed.Serial)
				http.Redirect(w, r, newURL.String(), http.StatusTemporaryRedirect)
				return
			}
			if len(v) > 0 && v[0] != di {
				// something is wrong, the device info in the query params does not match
				// the one in the header, so we just log the error and continue to next
				level.Error(logger).Log("msg", "device info in query params does not match header", "header", di, "query", v[0])
			}
			level.Info(logger).Log("msg", "handling mdm sso: proceed to next", "host_uuid", parsed.UDID, "serial", parsed.Serial)
		}

		next.ServeHTTP(w, r)
	}
}
