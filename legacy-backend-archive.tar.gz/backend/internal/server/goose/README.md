# goose

Goose is a database migration tool. Manage your database's evolution by creating incremental SQL files or Go functions.

## Contents

The contents in this directory are a copy (made in December 2023) of <https://github.com/notawar/goose> which is a fork of <https://github.com/pressly/goose> with some customizations for working with [Mobius](https://github.com/notawar/mobius).
